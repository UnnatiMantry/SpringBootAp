# Java Major Assignment

Java Track Major Assignment
Using 
Spring Boot 
Restful Api 
