package com.hashedin.javamajorassignment.controller;

import com.hashedin.javamajorassignment.entities.Employee;
import com.hashedin.javamajorassignment.service.EmployeeService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @RequestMapping("/")
    String index(){
        return "Building applications in HU is fun";
    }

    @RequestMapping("/hu")
    String hu(){
        return "HU is awesome";
    }


}
