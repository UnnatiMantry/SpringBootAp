package com.hashedin.javamajorassignment.service;

public class employeeOnboarding {

}
