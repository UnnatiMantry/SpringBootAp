package com.hashedin.javamajorassignment.entities;

public class Int {
}
