package com.hashedin.javamajorassignment.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.text.SimpleDateFormat;
import java.util.*;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;



@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Employee-TBL")
public class Employee {
    @Id
    @GeneratedValue
    private int id;
    private String empcode;
    private String email;
    private String fname;
    private String lname;
    private String address;
    private String city;
    private int pin;
    private String state;
    private long primaryContact;
    private long secondaryContact;
    private String role;
    private String jDate;
    private Calendar joiningDate;
    private Calendar probationPeriodEndDate;
    private Calendar noticePeriodEndDate;
}

    /*public Employee(int id, String fname, String lname, String address, String city, int pin, String state, long primaryContact, long secondaryContact, String role, Calendar joiningDate) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.address = address;
        this.city = city;
        this.pin = pin;
        this.state = state;
        this.primaryContact = primaryContact;
        this.secondaryContact = secondaryContact;
        this.role = role;
        this.joiningDate = joiningDate;
    }

    public int getId() {
        return id;
    }

    public String getStringId() {
        String strId = String.valueOf(id);
        if(strId.length() > 3)
            return strId;
        else if( strId.length() > 2)
            return "0"+strId;
        else if(strId.length() >1)
            return "00"+strId;
        else
            return "000"+strId;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public long getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(long primaryContact) {
        this.primaryContact = primaryContact;
    }

    public long getSecondaryContact() {
        return secondaryContact;
    }

    public void setSecondaryContact(long secondaryContact) {
        this.secondaryContact = secondaryContact;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Calendar getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(Calendar joiningDate) {
        this.joiningDate = joiningDate;
    }

    public int getJoiningYear (){
        return joiningDate.get(Calendar.YEAR);
    }
}*/
