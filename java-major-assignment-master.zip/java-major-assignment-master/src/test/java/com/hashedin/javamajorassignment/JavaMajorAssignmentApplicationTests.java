package com.hashedin.javamajorassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMajorAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
